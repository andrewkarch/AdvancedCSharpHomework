﻿/*
	Delete all current test data from the tables.
 */
/*Level 6*/
DELETE FROM purchase_order_product;
/*Level 5*/
DELETE FROM purchase_order;
/*Level 4*/
DELETE FROM customer_shipping_address;
/*Level 3*/
DELETE FROM employee;
DELETE FROM customer;
/*Level 2*/
DELETE FROM position;
DELETE FROM account;
DELETE FROM inventory;
/*Level 1*/
DELETE FROM authorization_level;
DELETE FROM department;
DELETE FROM product;